package com.traf7.youngrio.chatroom;

public interface ActivityCallback {
    void openChat();
    void openCreateAccount();
    void logout();
}